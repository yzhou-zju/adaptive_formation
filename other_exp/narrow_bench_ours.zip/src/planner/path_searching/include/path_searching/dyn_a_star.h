/***
 * @Author: ztr
 * @Date: 2022-05-12 00:02:25
 * @LastEditTime: 2022-05-12 00:02:25
 * @LastEditors: ztr
 * @Description:
 * @FilePath: /Pipline-Swarm-Formation/src/planner/path_searching/include/path_searching/dyn_a_star.h
 */
#ifndef _DYN_A_STAR_H_
#define _DYN_A_STAR_H_

#include <iostream>
#include <ros/ros.h>
#include <ros/console.h>
#include <Eigen/Eigen>
#include <plan_env/grid_map.h>
#include <queue>
#include <plan_env/raycast.h>

constexpr double inf = 1 >> 20;
struct GridNode;
typedef GridNode *GridNodePtr;

struct GridNode
{
	enum enum_state
	{
		OPENSET = 1,
		CLOSEDSET = 2,
		UNDEFINED = 3
	};

	int rounds{0}; // Distinguish every call
	enum enum_state state
	{
		UNDEFINED
	};
	Eigen::Vector3i index;

	double gScore{inf}, fScore{inf};
	GridNodePtr cameFrom{NULL};
};

class NodeComparator_Astar
{
public:
	bool operator()(GridNodePtr node1, GridNodePtr node2)
	{
		return node1->fScore > node2->fScore;
	}
};

class AStar
{
private:
	GridMap::Ptr grid_map_;

	inline void coord2gridIndexFast(const double x, const double y, const double z, int &id_x, int &id_y, int &id_z);

	double getDiagHeu(GridNodePtr node1, GridNodePtr node2);
	double getManhHeu(GridNodePtr node1, GridNodePtr node2);
	double getEuclHeu(GridNodePtr node1, GridNodePtr node2);
	inline double getHeu(GridNodePtr node1, GridNodePtr node2);

	bool ConvertToIndexAndAdjustStartEndPoints(const Eigen::Vector3d start_pt, const Eigen::Vector3d end_pt, Eigen::Vector3i &start_idx, Eigen::Vector3i &end_idx);

	inline Eigen::Vector3d Index2Coord(const Eigen::Vector3i &index) const;
	inline bool Coord2Index(const Eigen::Vector3d &pt, Eigen::Vector3i &idx) const;
	bool lineVisib(const Eigen::Vector3d &p1, const Eigen::Vector3d &p2, double thresh, Eigen::Vector3d &pc);

	// bool (*checkOccupancyPtr)( const Eigen::Vector3d &pos );

	inline bool checkOccupancy(const Eigen::Vector3d &pos) { return (bool)grid_map_->getInflateOccupancy(Eigen::Vector3d(pos.x(), pos.y(), 1.0)); }
	inline bool checkOccupancy_esdf(const Eigen::Vector3d &pos, double ddd, double lll)
	{
		// Eigen::Vector3d pos_x = pos + ddd * Eigen::Vector3d(lll, 0.0, 0.0);
		// Eigen::Vector3d pos_x2 = pos + ddd * Eigen::Vector3d(-lll, 0.0, 0.0);
		// Eigen::Vector3d pos_y = pos + ddd * Eigen::Vector3d(0.0, (1 / lll), 0.0);
		// Eigen::Vector3d pos_y2 = pos + ddd * Eigen::Vector3d(0.0, -(1 / lll), 0.0);
		// if (grid_map_->getDistance(pos_x) < 0.01 || grid_map_->getDistance(pos_x2) < 0.01 || grid_map_->getDistance(pos_y) < 0.01 || grid_map_->getDistance(pos_y2) < 0.01)
		// {
		// 	return true;
		// }
		// else
		// {
		// 	return false;
		// }
		for (double theta = 0.0; theta < 2 * M_PI; theta += M_PI / 8.0)
		{
			for (double step_obs = 0.0; step_obs < 1.0; step_obs = step_obs + 0.2)
			{
				// Eigen::Vector2d pos = Eigen::Vector2d(c.x(), c.y()) + 0.0 * Eigen::Vector2d(1.0*(shape_to_graph[point_i].x() - c.x()), (1.0/1.0)*(shape_to_graph[point_i].y()-c.y()));
				Eigen::Vector3d pos_real = Eigen::Vector3d(pos.x(), pos.y(), 1.0) + step_obs * ddd * Eigen::Vector3d(lll * cos(theta), (1 / lll) * sin(theta), 0.0);

				if (grid_map_->getDistance(pos_real) < 0.1)
				{
					return true;
				}
			}
		}
		return false;
		// if (grid_map_->getDistance(pos) < resolution_)
		// 	return true;
		// else
		// 	return false;
	}


	inline bool checkOccupancy(const Eigen::Vector3d &pos, double ddd, double lll)
	{
		for (double theta = 0.0; theta < 2 * M_PI; theta += M_PI / 8.0)
		{
			for (double step_obs = 0.0; step_obs < 1.0; step_obs = step_obs + 0.05)
			{
				// Eigen::Vector2d pos = Eigen::Vector2d(c.x(), c.y()) + 0.0 * Eigen::Vector2d(1.0*(shape_to_graph[point_i].x() - c.x()), (1.0/1.0)*(shape_to_graph[point_i].y()-c.y()));
				Eigen::Vector3d pos_real = Eigen::Vector3d(pos.x(), pos.y(), 1.0) + step_obs * ddd * Eigen::Vector3d(lll * cos(theta), (1 / lll) * sin(theta), 0.0);

				if (grid_map_->getInflateOccupancy(pos_real))
				{
					return true;
				}
			}
		}
		return false;
	}

	std::vector<GridNodePtr> retrievePath(GridNodePtr current);

	double step_size_, inv_step_size_;
	Eigen::Vector3d center_;
	Eigen::Vector3i CENTER_IDX_, POOL_SIZE_;
	const double tie_breaker_ = 1.0 + 1.0 / 10000;

	std::vector<GridNodePtr> gridPath_;

	GridNodePtr ***GridNodeMap_;
	std::priority_queue<GridNodePtr, std::vector<GridNodePtr>, NodeComparator_Astar> openSet_;

	int rounds_{0};
	double resolution_;
	Eigen::Vector3d offset_;

public:
	typedef std::shared_ptr<AStar> Ptr;

	AStar() {};
	~AStar();

	void initGridMap(GridMap::Ptr occ_map, const Eigen::Vector3i pool_size);

	bool AstarSearch(const double step_size, Eigen::Vector3d start_pt, Eigen::Vector3d end_pt, bool use_esdf_check, double safe_dist, double safe_lll);

	std::vector<Eigen::Vector3d> getPath();

	inline double checkOccupancy_num(const Eigen::Vector3d &pos, double ddd, double lll)
	{
		double occup = 0.0;
		for (double theta = 0.0; theta < 2 * M_PI; theta += M_PI / 8.0)
		{
			for (double step_obs = 0.0; step_obs < 1.0; step_obs = step_obs + 0.1)
			{
				// Eigen::Vector2d pos = Eigen::Vector2d(c.x(), c.y()) + 0.0 * Eigen::Vector2d(1.0*(shape_to_graph[point_i].x() - c.x()), (1.0/1.0)*(shape_to_graph[point_i].y()-c.y()));
				Eigen::Vector3d pos_real = Eigen::Vector3d(pos.x(), pos.y(), 1.0) + step_obs * ddd * Eigen::Vector3d(lll*lll * cos(theta), (1 / (lll*lll)) * sin(theta), 0.0);

				if (grid_map_->getDistance(pos_real) < 0.2)
				{
					occup = occup + 1.0;
				}
			}
		}
		return occup;
	}

	bool astarSearchAndGetSimplePath(const double step_size, Eigen::Vector3d start_pt,
									 Eigen::Vector3d end_pt, std::vector<Eigen::Vector3d> &final_simple_path, std::vector<Eigen::Vector3d> &a_star_path, double safe_dist, double safe_lll);
};

inline double AStar::getHeu(GridNodePtr node1, GridNodePtr node2)
{
	return 1.0 * tie_breaker_ * getDiagHeu(node1, node2);
}

inline Eigen::Vector3d AStar::Index2Coord(const Eigen::Vector3i &index) const
{
	return ((index - CENTER_IDX_).cast<double>() * step_size_) + center_;
};

inline bool AStar::Coord2Index(const Eigen::Vector3d &pt, Eigen::Vector3i &idx) const
{
	idx = ((pt - center_) * inv_step_size_ + Eigen::Vector3d(0.5, 0.5, 0.5)).cast<int>() + CENTER_IDX_;

	if (idx(0) < 0 || idx(0) >= POOL_SIZE_(0) || idx(1) < 0 || idx(1) >= POOL_SIZE_(1) || idx(2) < 0 || idx(2) >= POOL_SIZE_(2))
	{
		ROS_ERROR("Ran out of pool, index=%d %d %d", idx(0), idx(1), idx(2));
		return false;
	}

	return true;
};

#endif
