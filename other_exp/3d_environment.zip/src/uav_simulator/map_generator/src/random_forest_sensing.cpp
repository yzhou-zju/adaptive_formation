#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
// #include <pcl/search/kdtree.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl_conversions/pcl_conversions.h>
#include <iostream>

#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Vector3.h>
#include <math.h>
#include <nav_msgs/Odometry.h>
#include <ros/console.h>
#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <Eigen/Eigen>
#include <random>

using namespace std;

// pcl::search::KdTree<pcl::PointXYZ> kdtreeLocalMap;
pcl::KdTreeFLANN<pcl::PointXYZ> kdtreeLocalMap;
vector<int> pointIdxRadiusSearch;
vector<float> pointRadiusSquaredDistance;

random_device rd;
// default_random_engine eng(4);
default_random_engine eng;
uniform_real_distribution<double> rand_x;
uniform_real_distribution<double> rand_y;
uniform_real_distribution<double> rand_w;
uniform_real_distribution<double> rand_h;
uniform_real_distribution<double> rand_inf;

ros::Publisher _local_map_pub;
ros::Publisher _all_map_pub;
ros::Publisher click_map_pub_;
ros::Subscriber _odom_sub;

vector<double> _state;

int _obs_num;
double _x_size, _y_size, _z_size;
double _x_l, _x_h, _y_l, _y_h, _w_l, _w_h, _h_l, _h_h;
double _z_limit, _sensing_range, _resolution, _pub_rate;
double _min_dist;
int fix_obs_type_;

bool _map_ok = false;
bool _has_odom = false;

int circle_num_;
double radius_l_, radius_h_, z_l_, z_h_;
double theta_;
uniform_real_distribution<double> rand_radius_;
uniform_real_distribution<double> rand_radius2_;
uniform_real_distribution<double> rand_theta_;
uniform_real_distribution<double> rand_z_;

sensor_msgs::PointCloud2 globalMap_pcd;
pcl::PointCloud<pcl::PointXYZ> cloudMap;

sensor_msgs::PointCloud2 localMap_pcd;
pcl::PointCloud<pcl::PointXYZ> clicked_cloud_;

void GenerateWall(double x_l, double x_h,
                  double y_l, double y_h,
                  double z_l, double z_h,
                  pcl::PointCloud<pcl::PointXYZ> &cloudMap)
{
  int x_num, y_num, z_num;
  x_num = ceil((x_h - x_l) / _resolution);
  y_num = ceil((y_h - y_l) / _resolution);
  z_num = ceil((z_h - z_l) / _resolution);
  pcl::PointXYZ pt;
  for (int i = 0; i < x_num; i++)
    for (int j = 0; j < y_num; j++)
      for (int k = 0; k < z_num; k++)
      {
        pt.x = x_l + i * _resolution;
        pt.y = y_l + j * _resolution;
        pt.z = z_l + k * _resolution;
        cloudMap.push_back(pt);
      }
}

void RandomMapGenerate()
{
  pcl::PointXYZ pt_random;

  rand_x = uniform_real_distribution<double>(_x_l, _x_h);
  rand_y = uniform_real_distribution<double>(_y_l, _y_h);
  rand_w = uniform_real_distribution<double>(_w_l, _w_h);
  rand_h = uniform_real_distribution<double>(_h_l, _h_h);

  rand_radius_ = uniform_real_distribution<double>(radius_l_, radius_h_);
  rand_radius2_ = uniform_real_distribution<double>(radius_l_, 1.2);
  rand_theta_ = uniform_real_distribution<double>(-theta_, theta_);
  rand_z_ = uniform_real_distribution<double>(z_l_, z_h_);

  // generate polar obs
  for (int i = 0; i < _obs_num; i++)
  {
    double x, y, w, h;
    x = rand_x(eng);
    y = rand_y(eng);
    w = rand_w(eng);

    x = floor(x / _resolution) * _resolution + _resolution / 2.0;
    y = floor(y / _resolution) * _resolution + _resolution / 2.0;

    int widNum = ceil(w / _resolution);

    for (int r = -widNum / 2.0; r < widNum / 2.0; r++)
      for (int s = -widNum / 2.0; s < widNum / 2.0; s++)
      {
        h = rand_h(eng);
        int heiNum = ceil(h / _resolution);
        for (int t = -20; t < heiNum; t++)
        {
          pt_random.x = x + (r + 0.5) * _resolution + 1e-2;
          pt_random.y = y + (s + 0.5) * _resolution + 1e-2;
          pt_random.z = (t + 0.5) * _resolution + 1e-2;
          cloudMap.points.push_back(pt_random);
        }
      }
  }

  // generate circle obs
  for (int i = 0; i < circle_num_; ++i)
  {
    double x, y, z;
    x = rand_x(eng);
    y = rand_y(eng);
    z = rand_z_(eng);

    x = floor(x / _resolution) * _resolution + _resolution / 2.0;
    y = floor(y / _resolution) * _resolution + _resolution / 2.0;
    z = floor(z / _resolution) * _resolution + _resolution / 2.0;

    Eigen::Vector3d translate(x, y, z);

    double theta = rand_theta_(eng);
    Eigen::Matrix3d rotate;
    rotate << cos(theta), -sin(theta), 0.0, sin(theta), cos(theta), 0.0, 0, 0,
        1;

    double radius1 = rand_radius_(eng);
    double radius2 = rand_radius2_(eng);

    // draw a circle centered at (x,y,z)
    Eigen::Vector3d cpt;
    for (double angle = 0.0; angle < 6.282; angle += _resolution / 2)
    {
      cpt(0) = 0.0;
      cpt(1) = radius1 * cos(angle);
      cpt(2) = radius2 * sin(angle);

      // inflate
      Eigen::Vector3d cpt_if;
      for (int ifx = -0; ifx <= 0; ++ifx)
        for (int ify = -0; ify <= 0; ++ify)
          for (int ifz = -0; ifz <= 0; ++ifz)
          {
            cpt_if = cpt + Eigen::Vector3d(ifx * _resolution, ify * _resolution,
                                           ifz * _resolution);
            cpt_if = rotate * cpt_if + Eigen::Vector3d(x, y, z);
            pt_random.x = cpt_if(0);
            pt_random.y = cpt_if(1);
            pt_random.z = cpt_if(2);
            cloudMap.push_back(pt_random);
          }
    }
  }

  cloudMap.width = cloudMap.points.size();
  cloudMap.height = 1;
  cloudMap.is_dense = true;

  ROS_WARN("Finished generate random map ");

  kdtreeLocalMap.setInputCloud(cloudMap.makeShared());

  _map_ok = true;
}

void RandomMapGenerateCylinder()
{
  pcl::PointXYZ pt_random;

  vector<Eigen::Vector2d> obs_position;

  rand_x = uniform_real_distribution<double>(_x_l, _x_h);
  rand_y = uniform_real_distribution<double>(_y_l, _y_h);
  rand_w = uniform_real_distribution<double>(_w_l, _w_h);
  rand_h = uniform_real_distribution<double>(_h_l, _h_h);
  rand_inf = uniform_real_distribution<double>(0.5, 1.5);

  rand_radius_ = uniform_real_distribution<double>(radius_l_, radius_h_);
  rand_radius2_ = uniform_real_distribution<double>(radius_l_, 1.2);
  rand_theta_ = uniform_real_distribution<double>(-theta_, theta_);
  rand_z_ = uniform_real_distribution<double>(z_l_, z_h_);

  // generate polar obs
  for (int i = 0; i < _obs_num && ros::ok(); i++)
  {
    double x, y, w, h, inf;
    x = rand_x(eng);
    y = rand_y(eng);
    w = rand_w(eng);
    inf = rand_inf(eng);

    bool flag_continue = false;
    for (auto p : obs_position) // 如果距离太近，新生成的障碍物不能用，重新生成
      if ((Eigen::Vector2d(x, y) - p).norm() < _min_dist /*metres*/)
      {
        i--;
        flag_continue = true;
        break;
      }
    if (flag_continue)
      continue;

    obs_position.push_back(Eigen::Vector2d(x, y));

    x = floor(x / _resolution) * _resolution + _resolution / 2.0;
    y = floor(y / _resolution) * _resolution + _resolution / 2.0;

    int widNum = ceil((w * inf) / _resolution);
    double radius = (w * inf) / 2;

    for (int r = -widNum / 2.0; r < widNum / 2.0; r++)
      for (int s = -widNum / 2.0; s < widNum / 2.0; s++)
      {
        h = rand_h(eng);
        int heiNum = ceil(h / _resolution);
        for (int t = -10; t < heiNum; t++)
        {
          double temp_x = x + (r + 0.5) * _resolution + 1e-2;
          double temp_y = y + (s + 0.5) * _resolution + 1e-2;
          double temp_z = (t + 0.5) * _resolution + 1e-2;
          if ((Eigen::Vector2d(temp_x, temp_y) - Eigen::Vector2d(x, y)).norm() <= radius)
          {
            pt_random.x = temp_x;
            pt_random.y = temp_y;
            pt_random.z = temp_z;
            cloudMap.points.push_back(pt_random);
          }
        }
      }
  }

  // generate circle obs
  for (int i = 0; i < circle_num_; ++i)
  {
    double x, y, z;
    x = rand_x(eng);
    y = rand_y(eng);
    z = rand_z_(eng);

    x = floor(x / _resolution) * _resolution + _resolution / 2.0;
    y = floor(y / _resolution) * _resolution + _resolution / 2.0;
    z = floor(z / _resolution) * _resolution + _resolution / 2.0;

    Eigen::Vector3d translate(x, y, z);

    double theta = rand_theta_(eng);
    Eigen::Matrix3d rotate;
    rotate << cos(theta), -sin(theta), 0.0, sin(theta), cos(theta), 0.0, 0, 0,
        1;

    double radius1 = rand_radius_(eng);
    double radius2 = rand_radius2_(eng);

    // draw a circle centered at (x,y,z)
    Eigen::Vector3d cpt;
    for (double angle = 0.0; angle < 6.282; angle += _resolution / 2)
    {
      cpt(0) = 0.0;
      cpt(1) = radius1 * cos(angle);
      cpt(2) = radius2 * sin(angle);

      // inflate
      Eigen::Vector3d cpt_if;
      for (int ifx = -0; ifx <= 0; ++ifx)
        for (int ify = -0; ify <= 0; ++ify)
          for (int ifz = -0; ifz <= 0; ++ifz)
          {
            cpt_if = cpt + Eigen::Vector3d(ifx * _resolution, ify * _resolution,
                                           ifz * _resolution);
            cpt_if = rotate * cpt_if + Eigen::Vector3d(x, y, z);
            pt_random.x = cpt_if(0);
            pt_random.y = cpt_if(1);
            pt_random.z = cpt_if(2);
            cloudMap.push_back(pt_random);
          }
    }
  }
  /************************************************************************************************************************* */
double xxx = -32.0;
double yyy = 4.27;

// 旋转参数
double theta = 10.0 * M_PI / 180.0; // 转为弧度
double cos_t = cos(theta);
double sin_t = sin(theta);

// 旋转中心（障碍物几何中心）
double cx = xxx + 10.5 / 2.0; // -30.75
double cy = yyy;               // 4.0（近似中心）
double cz = (-2.0 + 4.0) / 2.0; // 1.0

for (double x = -0.0 + xxx; x <= 5.0 + xxx; x += 0.15)
{
    for (double z = -1.0; z <= 5.0; z += 0.15)
    {
        for (double y = 1.12 + yyy; y <= 5.0 + yyy; y += 0.15)
        {
            // 原始点
            double ox = x, oy = y, oz = z;

            // 1. 平移到局部坐标系（相对于中心）
            double lx = ox - cx;
            double ly = oy - cy;
            double lz = oz - cz;

            // 2. 绕 Z 轴旋转
            double rx = lx * cos_t - ly * sin_t;
            double ry = lx * sin_t + ly * cos_t;
            double rz = lz; // z 不变

            // 3. 平移回世界坐标
            pt_random.x = rx + cx;
            pt_random.y = ry + cy;
            pt_random.z = rz + cz;

            cloudMap.push_back(pt_random);
        }
    }
}
// 下半部分同样处理
for (double x = -0.0 + xxx; x <= 5.0 + xxx; x += 0.15)
{
    for (double z = -1.0; z <= 5.0; z += 0.15)
    {
        for (double y = -5.0 + yyy; y <= -1.0 + yyy; y += 0.15)
        {
            double ox = x, oy = y, oz = z;

            double lx = ox - cx;
            double ly = oy - cy;
            double lz = oz - cz;

            double rx = lx * cos_t - ly * sin_t;
            double ry = lx * sin_t + ly * cos_t;
            double rz = lz;

            pt_random.x = rx + cx;
            pt_random.y = ry + cy;
            pt_random.z = rz + cz;

            cloudMap.push_back(pt_random);
        }
    }
}


// 旋转中心（障碍物几何中心）
xxx = -35.0;
yyy = 3.75;
// 旋转参数
theta = 2.0 * M_PI / 180.0; // 转为弧度
cos_t = cos(theta);
sin_t = sin(theta);

cx = xxx + 10.5 / 2.0; // -30.75
cy = yyy;               // 4.0（近似中心）
cz = (-2.0 + 4.0) / 2.0; // 1.0

for (double x = -0.0 + xxx; x <= 3.7 + xxx; x += 0.15)
{
    for (double z = -1.0; z <= 5.0; z += 0.15)
    {
        for (double y = 1.4 + yyy; y <= 5.0 + yyy; y += 0.15)
        {
            // 原始点
            double ox = x, oy = y, oz = z;

            // 1. 平移到局部坐标系（相对于中心）
            double lx = ox - cx;
            double ly = oy - cy;
            double lz = oz - cz;

            // 2. 绕 Z 轴旋转
            double rx = lx * cos_t - ly * sin_t;
            double ry = lx * sin_t + ly * cos_t;
            double rz = lz; // z 不变

            // 3. 平移回世界坐标
            pt_random.x = rx + cx;
            pt_random.y = ry + cy;
            pt_random.z = rz + cz;

            cloudMap.push_back(pt_random);
        }
    }
}
// 下半部分同样处理
for (double x = -0.0 + xxx; x <= 3.7 + xxx; x += 0.15)
{
    for (double z = -1.0; z <= 5.0; z += 0.15)
    {
        for (double y = -5.0 + yyy; y <= -0.9 + yyy; y += 0.15)
        {
            double ox = x, oy = y, oz = z;

            double lx = ox - cx;
            double ly = oy - cy;
            double lz = oz - cz;

            double rx = lx * cos_t - ly * sin_t;
            double ry = lx * sin_t + ly * cos_t;
            double rz = lz;

            pt_random.x = rx + cx;
            pt_random.y = ry + cy;
            pt_random.z = rz + cz;

            cloudMap.push_back(pt_random);
        }
    }
}


// 旋转中心（障碍物几何中心）
xxx = -26.0;
yyy = 2.8;
// 旋转参数
theta = -15.0 * M_PI / 180.0; // 转为弧度
cos_t = cos(theta);
sin_t = sin(theta);

cx = xxx + 10.5 / 2.0; // -30.75
cy = yyy;               // 4.0（近似中心）
cz = (-2.0 + 4.0) / 2.0; // 1.0

for (double x = -0.0 + xxx; x <= 5.5 + xxx; x += 0.15)
{
    for (double z = -1.0; z <= 5.0; z += 0.15)
    {
        for (double y = 1.0 + yyy; y <= 5.0 + yyy; y += 0.15)
        {
            // 原始点
            double ox = x, oy = y, oz = z;

            // 1. 平移到局部坐标系（相对于中心）
            double lx = ox - cx;
            double ly = oy - cy;
            double lz = oz - cz;

            // 2. 绕 Z 轴旋转
            double rx = lx * cos_t - ly * sin_t;
            double ry = lx * sin_t + ly * cos_t;
            double rz = lz; // z 不变

            // 3. 平移回世界坐标
            pt_random.x = rx + cx;
            pt_random.y = ry + cy;
            pt_random.z = rz + cz;

            cloudMap.push_back(pt_random);
        }
    }
}
// 下半部分同样处理
for (double x = -0.0 + xxx; x <= 5.5 + xxx; x += 0.15)
{
    for (double z = -1.0; z <= 5.0; z += 0.15)
    {
        for (double y = -5.0 + yyy; y <= -1.0 + yyy; y += 0.15)
        {
            double ox = x, oy = y, oz = z;

            double lx = ox - cx;
            double ly = oy - cy;
            double lz = oz - cz;

            double rx = lx * cos_t - ly * sin_t;
            double ry = lx * sin_t + ly * cos_t;
            double rz = lz;

            pt_random.x = rx + cx;
            pt_random.y = ry + cy;
            pt_random.z = rz + cz;

            cloudMap.push_back(pt_random);
        }
    }
}




// === 高斯凸山包（沿 z 轴凸起）===
// 全局高斯山包参数：每个 {cx, cy, height, sigma}
std::vector<std::vector<double>> gaussians = {
    {-30.0, 3.4, 2.4, 1.5},
    {-15.0, 3.2, 2.0, 2.0},
    {  -26.0, 6.0, 2.2, 1.8},
    { -27.0, 11.0, 2.0, 1.9},
    {-14.0,   -3.0, 1.1, 2.2},
    { -31.0,   -4.0, 2.6, 1.6},
    { -21.0,   -2.0, 1.8, 5.0},
    { -10.0,   10.0, 1.7, 3.3},
    {  -6.0,  -3.0, 1.5, 3.2},
    { -34.0,  8.0, 2.3, 1.6}
    // 你可以任意修改这些参数！
};

double global_z_base = -1.2;  // 全局底部 Z
double x_min = -45.0, x_max = 0.0;
double y_min = -14.0, y_max = 19.0;
double step = 0.05;

for (double x = x_min; x <= x_max; x += step)
{
    for (double y = y_min; y <= y_max; y += step)
    {
        double total_z_offset = 0.0;

        // 叠加所有高斯贡献
        for (const auto& g : gaussians)
        {
            double cx = g[0];
            double cy = g[1];
            double h  = g[2];
            double sigma = g[3];

            double dx = x - cx;
            double dy = y - cy;
            double exponent = -(dx * dx + dy * dy) / (2.0 * sigma * sigma);
            total_z_offset += h * std::exp(exponent);
        }

        double z = global_z_base + total_z_offset;

        pt_random.x = x;
        pt_random.y = y;
        pt_random.z = z;
        cloudMap.push_back(pt_random);
    }
}


// 旋转中心（障碍物几何中心）
xxx = -9.0;
yyy = 3.8;
// 旋转参数
theta = -2.0 * M_PI / 180.0; // 转为弧度
cos_t = cos(theta);
sin_t = sin(theta);

cx = xxx + 10.5 / 2.0; // -30.75
cy = yyy;               // 4.0（近似中心）
cz = (-2.0 + 4.0) / 2.0; // 1.0

for (double x = -0.0 + xxx; x <= 5.5 + xxx; x += 0.15)
{
    for (double z = -1.0; z <= 5.0; z += 0.15)
    {
        for (double y = 1.0 + yyy; y <= 6.0 + yyy; y += 0.15)
        {
            // 原始点
            double ox = x, oy = y, oz = z;

            // 1. 平移到局部坐标系（相对于中心）
            double lx = ox - cx;
            double ly = oy - cy;
            double lz = oz - cz;

            // 2. 绕 Z 轴旋转
            double rx = lx * cos_t - ly * sin_t;
            double ry = lx * sin_t + ly * cos_t;
            double rz = lz; // z 不变

            // 3. 平移回世界坐标
            pt_random.x = rx + cx;
            pt_random.y = ry + cy;
            pt_random.z = rz + cz;

            cloudMap.push_back(pt_random);
        }
    }
}

xxx = -19.0;
yyy = -5.7;
// 旋转参数
theta = -2.0 * M_PI / 180.0; // 转为弧度
cos_t = cos(theta);
sin_t = sin(theta);

cx = xxx + 10.5 / 2.0; // -30.75
cy = yyy;               // 4.0（近似中心）
cz = (-2.0 + 4.0) / 2.0; // 1.0

for (double x = -0.0 + xxx; x <= 5.5 + xxx; x += 0.15)
{
    for (double z = -1.0; z <= 5.0; z += 0.15)
    {
        for (double y = 1.0 + yyy; y <= 4.0 + yyy; y += 0.15)
        {
            // 原始点
            double ox = x, oy = y, oz = z;

            // 1. 平移到局部坐标系（相对于中心）
            double lx = ox - cx;
            double ly = oy - cy;
            double lz = oz - cz;

            // 2. 绕 Z 轴旋转
            double rx = lx * cos_t - ly * sin_t;
            double ry = lx * sin_t + ly * cos_t;
            double rz = lz; // z 不变

            // 3. 平移回世界坐标
            pt_random.x = rx + cx;
            pt_random.y = ry + cy;
            pt_random.z = rz + cz;

            cloudMap.push_back(pt_random);
        }
    }
}

xxx = -35.5;
yyy = -9.4;
// 旋转参数
theta = -2.0 * M_PI / 180.0; // 转为弧度
cos_t = cos(theta);
sin_t = sin(theta);

cx = xxx + 10.5 / 2.0; // -30.75
cy = yyy;               // 4.0（近似中心）
cz = (-2.0 + 4.0) / 2.0; // 1.0

for (double x = -0.0 + xxx; x <= 7.5 + xxx; x += 0.15)
{
    for (double z = -1.0; z <= 5.0; z += 0.15)
    {
        for (double y = 1.0 + yyy; y <= 4.0 + yyy; y += 0.15)
        {
            // 原始点
            double ox = x, oy = y, oz = z;

            // 1. 平移到局部坐标系（相对于中心）
            double lx = ox - cx;
            double ly = oy - cy;
            double lz = oz - cz;

            // 2. 绕 Z 轴旋转
            double rx = lx * cos_t - ly * sin_t;
            double ry = lx * sin_t + ly * cos_t;
            double rz = lz; // z 不变

            // 3. 平移回世界坐标
            pt_random.x = rx + cx;
            pt_random.y = ry + cy;
            pt_random.z = rz + cz;

            cloudMap.push_back(pt_random);
        }
    }
}




  cloudMap.width = cloudMap.points.size();
  cloudMap.height = 1;
  cloudMap.is_dense = true;

  ROS_WARN("Finished generate random map ");

  kdtreeLocalMap.setInputCloud(cloudMap.makeShared());

  _map_ok = true;
}

void FixMapGenerate()
{

  switch (fix_obs_type_)
  {
  case 0: // NONE_FIX
  {
    break;
  }

  case 1: // WALL_WITH_HOLE
  {
    double x_l, x_h, y_l, y_h, z_l, z_h;
    x_l = -3.2;
    x_h = 6.2;
    y_l = -_y_size / 2;
    y_h = -1.6;
    z_l = -1.0;
    z_h = _z_size;
    GenerateWall(x_l, x_h, y_l, y_h, z_l, z_h, cloudMap);
    x_l = -3.2;
    x_h = 6.2;
    y_l = 1.6;
    y_h = _y_size / 2;
    z_l = -1.0;
    z_h = _z_size;
    GenerateWall(x_l, x_h, y_l, y_h, z_l, z_h, cloudMap);
    break;
  }

  case 2: // WALL_WITHOUT_HOLE
  {
    double x_l, x_h, y_l, y_h, z_l, z_h;
    x_l = -10.5;
    x_h = -9.5;
    y_l = -2.0;
    y_h = 2.0;
    z_l = -1.0;
    z_h = _z_size;
    GenerateWall(x_l, x_h, y_l, y_h, z_l, z_h, cloudMap);
    break;
  }

  case 3: // A TEXT WALL_
  {
    double x_l, x_h, y_l, y_h, z_l, z_h;
    x_l = -17.0;
    x_h = 5.0;
    y_l = -6.5;
    y_h = -4.5;
    z_l = -1.0;
    z_h = _z_size;
    GenerateWall(x_l, x_h, y_l, y_h, z_l, z_h, cloudMap);
    break;
  }
  }

  ROS_WARN("Finished generate fixed map ");
}

void clickCallback(const geometry_msgs::PoseStamped &msg)
{
  double x = msg.pose.position.x;
  double y = msg.pose.position.y;
  double w = rand_w(eng);
  double h;
  pcl::PointXYZ pt_random;

  x = floor(x / _resolution) * _resolution + _resolution / 2.0;
  y = floor(y / _resolution) * _resolution + _resolution / 2.0;

  int widNum = ceil(w / _resolution);

  for (int r = -widNum / 2.0; r < widNum / 2.0; r++)
    for (int s = -widNum / 2.0; s < widNum / 2.0; s++)
    {
      h = rand_h(eng);
      int heiNum = ceil(h / _resolution);
      for (int t = -1; t < heiNum; t++)
      {
        pt_random.x = x + (r + 0.5) * _resolution + 1e-2;
        pt_random.y = y + (s + 0.5) * _resolution + 1e-2;
        pt_random.z = (t + 0.5) * _resolution + 1e-2;
        clicked_cloud_.points.push_back(pt_random);
        cloudMap.points.push_back(pt_random);
      }
    }
  clicked_cloud_.width = clicked_cloud_.points.size();
  clicked_cloud_.height = 1;
  clicked_cloud_.is_dense = true;

  pcl::toROSMsg(clicked_cloud_, localMap_pcd);
  localMap_pcd.header.frame_id = "world";
  click_map_pub_.publish(localMap_pcd);

  cloudMap.width = cloudMap.points.size();

  return;
}

int i = 0;
void pubPoints()
{
  while (ros::ok())
  {
    ros::spinOnce();
    if (_map_ok)
      break;
  }

  pcl::toROSMsg(cloudMap, globalMap_pcd);
  globalMap_pcd.header.frame_id = "world";
  _all_map_pub.publish(globalMap_pcd);
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "random_map_sensing");
  ros::NodeHandle n("~");

  _local_map_pub = n.advertise<sensor_msgs::PointCloud2>("/map_generator/local_cloud", 1);
  _all_map_pub = n.advertise<sensor_msgs::PointCloud2>("/map_generator/global_cloud", 1);

  click_map_pub_ =
      n.advertise<sensor_msgs::PointCloud2>("/pcl_render_node/local_map", 1);

  n.param("map/x_size", _x_size, 50.0);
  n.param("map/y_size", _y_size, 50.0);
  n.param("map/z_size", _z_size, 5.0);
  n.param("map/obs_num", _obs_num, 30);
  n.param("map/resolution", _resolution, 0.1);
  n.param("map/circle_num", circle_num_, 30);

  n.param("ObstacleShape/lower_rad", _w_l, 0.2);
  n.param("ObstacleShape/upper_rad", _w_h, 0.3);
  n.param("ObstacleShape/lower_hei", _h_l, 3.0);
  n.param("ObstacleShape/upper_hei", _h_h, 7.0);

  n.param("ObstacleShape/radius_l", radius_l_, 7.0);
  n.param("ObstacleShape/radius_h", radius_h_, 7.0);
  n.param("ObstacleShape/z_l", z_l_, 7.0);
  n.param("ObstacleShape/z_h", z_h_, 7.0);
  n.param("ObstacleShape/theta", theta_, 7.0);
  n.param("fix_obs_type", fix_obs_type_, 0);

  n.param("pub_rate", _pub_rate, 10.0);
  n.param("min_distance", _min_dist, 1.0);

  _x_l = -_x_size / 2.0;
  _x_h = +_x_size / 2.0;

  _y_l = -_y_size / 2.0;
  _y_h = +_y_size / 2.0;

  _obs_num = min(_obs_num, (int)_x_size * 10);
  _z_limit = _z_size;

  ros::Duration(0.5).sleep();

  // unsigned int seed = rd();
  // unsigned int seed = 3587752923; // only for test
  unsigned int seed = 1233482073;  // quanlun: 04-07
  // unsigned int seed = 2133482073;  // quanlun: 04-07
  // unsigned int seed = 1238785342;  // quanlun: 04-06

  cout << "seed = " << seed << " ~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~" << endl;
  eng.seed(seed);

  // RandomMapGenerate();  wait to debug
  RandomMapGenerateCylinder();
  FixMapGenerate();

  ros::Rate loop_rate(_pub_rate);

  // only for vrb benchmark
  // int i=0;
  // while (ros::ok())
  // {
  //   if (i<5){
  //     pubPoints();
  //     i++;
  //   }
  //   ros::spinOnce();
  //   loop_rate.sleep();
  // }

  // real map
  while (ros::ok())
  {
    pubPoints();
    ros::spinOnce();
    loop_rate.sleep();
  }
}

